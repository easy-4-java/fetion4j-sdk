/**
 * Project  : MapleFetion
 * Package  : test
 * File     : PassEncrypter.java
 * Author   : solosky < solosky772@qq.com >
 * Date     : 2009-11-16
 * Modified : 2009-11-16
 * License  : Apache License 2.0 
 */
package net.apexes.fetion4j.core.client.auth;

import net.apexes.fetion4j.core.util.ConvertHelper;
import net.apexes.fetion4j.core.util.DigestHelper;

/**
 * Password encryption utility for the Fetion V4 protocol. Produces SHA-1
 * hashes of the password combined with the Fetion domain or user ID.
 *
 * @author <a href="https://github.com/loong10k">@Loong Wan</a>
 * @since 3.0.0
 * @see net.apexes.fetion4j.core.util.DigestHelper
 */
public class PasswordEncrypterV4 {

    public static String encryptV4(int userid, String plainpass) {
        String passHex = encryptV4(plainpass);
        return doHash(ConvertHelper.int2Byte(userid), ConvertHelper.hexString2ByteNoSpace(passHex));
    }

    public static String encryptV4(String plainpass) {
        return doHash(ConvertHelper.string2Byte("fetion.com.cn:"), ConvertHelper.string2Byte(plainpass));
    }

    private static String doHash(byte[] b1, byte[] b2) {
        byte[] dst = new byte[b1.length + b2.length];
        System.arraycopy(b1, 0, dst, 0, b1.length);
        System.arraycopy(b2, 0, dst, b1.length, b2.length);
        byte[] res = DigestHelper.SHA1(dst);
        return ConvertHelper.byte2HexStringWithoutSpace(res);
    }

    public static String encryptV4Temp(int userid, String digest) {
        return doHash(ConvertHelper.int2Byte(userid), ConvertHelper.hexString2ByteNoSpace(digest));
    }
}
